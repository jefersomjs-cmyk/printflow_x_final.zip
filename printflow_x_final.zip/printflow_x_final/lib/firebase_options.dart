import 'package:firebase_core/firebase_core.dart';
class DefaultFirebaseOptions { static const currentPlatform = FirebaseOptions(apiKey:'CONFIGURE_COM_FLUTTERFIRE',appId:'CONFIGURE_COM_FLUTTERFIRE',messagingSenderId:'CONFIGURE_COM_FLUTTERFIRE',projectId:'CONFIGURE_COM_FLUTTERFIRE'); }
